import React, { PureComponent } from "react";

export default class ChildComDecre extends PureComponent {
  // shouldComponentUpdate(nextProps, nextstate) {
  //   // console.log("Next Props: ", nextProps);
  //   //console.log("Next State: ", nextstate);
  //   if (nextProps.data === this.props.data) {
  //     return false;
  //   } else {
  //     return true;
  //   }
  // }
  render() {
    console.log("Decrement");
    return (
      <div>
        <h1>{this.props.data}</h1>
        <button onClick={this.props.func}>Decrement Click</button>
      </div>
    );
  }
}
