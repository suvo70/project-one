import React, { Component } from "react";
import ChildComDecre from "./ChildCompDecre";
import ChildCompIncre from "./ChildCompIncre";

export default class ParentComponent extends Component {
  state = {
    currentValue: 0,
    preValue: 0,
  };
  increment = () => {
    this.setState({
      currentValue: this.state.currentValue + 1,
      preValue: this.state.preValue,
    });
  };
  decrement = () => {
    this.setState({
      currentValue: this.state.currentValue,
      preValue: this.state.preValue - 1,
    });
  };
  render() {
    return (
      <div>
        <ChildCompIncre
          data={this.state.currentValue}
          func={this.increment}
        ></ChildCompIncre>
        <ChildComDecre
          data={this.state.preValue}
          func={this.decrement}
        ></ChildComDecre>
      </div>
    );
  }
}
