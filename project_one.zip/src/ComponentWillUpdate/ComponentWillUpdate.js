import React, { Component } from "react";

export default class ComponentWillUpdate extends Component {
  constructor() {
    super();
    this.state = {
      toggleUser: true,
    };
  }
  componentWillUnmount() {
    console.warn("ComponentWillMount call");
    alert("user has been deleted");
  }
  render() {
    return (
      <div>
        {this.state.toggleUser ? (
          <div>
            <h1>User Email : abc@gmail.com</h1>
          </div>
        ) : null}
        <button
          onClick={() => {
            this.setState({ toggleUser: false });
          }}
        >
          Delete User Info
        </button>
      </div>
    );
  }
}
