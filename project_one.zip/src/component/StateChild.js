import React from "react";

export default function StateChild(props) {
  return (
    <>
      {props.arrObj.map((obj, index) => (
        <React.Fragment key={index}>
          <h1>
            {obj.fname1} {obj.lname1}
            {obj.last}
          </h1>
        </React.Fragment>
      ))}
      <button onClick={props.handleFunc}>Change the value</button>
    </>
  );
}
