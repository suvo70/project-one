import React from "react";

function Test1() {
  //    React.createElement(
  //     "div",
  //     { id: "test" },
  //     "This ia another process to mention React JS",
  //     React.createElement(
  //       "h1",
  //       null,
  //       "This ia another process to mention React JS"
  //     ),
  //     React.createElement(
  //       "h2",
  //       { class: "test" },
  //       "This ia another process to mention React JS"
  //     )
  //   );

  // JSX --> Bable (React.creatElement)
  return (
    <div className="test">
      <h1>Hallow World!</h1>
      <p>This is created by JSX</p>
      <h2>I am not doing React JS</h2>
    </div>
  );
}

export default Test1;
