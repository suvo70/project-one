import React from "react";

export default function Test() {
  return (
    <div>
      <p>Hallo World!</p>
    </div>
  );
}
export function Next() {
  return (
    <div>
      <h1>We are now learning React JS</h1>
    </div>
  );
}
export function Plus() {
  return (
    <div>
      <h1>We are importing React JS Again</h1>
    </div>
  );
}
