import React, { useState } from "react";
import StateChild from "./StateChild";

// function StateChange() {
//   const [name, setNewName] = useState("This is a state value!");
//   const handleChange = () => {
//     setNewName("Name is changed");
//   };
//   return (
//     <>
//       <h1>{name}</h1>
//       <button onClick={handleChange}>Change the value</button>
//     </>
//   );
// }

// function StateChange() {
//   const [data, setNewName] = useState({
//     fname1: "Process ",
//     lname1: "is ",
//     last: "not Complete",
//   });
//   const handleChange = () => {
//     setNewName({ ...data, last: "Complete" });
//   };

//   return (
//     <>
//       <h1>
//         {data.fname1}
//         {data.lname1}
//         {data.last}
//       </h1>
//       <button onClick={handleChange}>Change the value</button>
//     </>
//   );
// }

// function StateChange() {
//   const [data, setNewName] = useState([
//     {
//       fname1: "Process ",
//       lname1: "is ",
//       last: "not Complete",
//     },
//     {
//       fname1: "Works ",
//       lname1: "are ",
//       last: "done",
//     },
//     {
//       fname1: "Action",
//       lname1: "was ",
//       last: "done",
//     },
//   ]);

//   const manage = [
//     {
//       fname1: "Process ",
//       lname1: "is ",
//       last: "not Complete",
//     },
//     {
//       fname1: "Works ",
//       lname1: "are ",
//       last: " not done",
//     },
//     {
//       fname1: "Action",
//       lname1: "was ",
//       last: "done",
//     },
//   ];
//   const handleChange = () => {
//     setNewName(manage);
//   };

//   return (
//     <>
//       {data.map((data, control) => (
//         <React.Fragment key={control}>
//           <h1>
//             {data.fname1} {data.lname1} {data.last}
//           </h1>
//         </React.Fragment>
//       ))}
//       <button onClick={handleChange}>Change the value</button>
//     </>
//   );
// }

function StateChange() {
  const [data, setNewName] = useState([
    {
      fname1: "Process ",
      lname1: "is ",
      last: "not Complete",
    },
    {
      fname1: "Works ",
      lname1: "are ",
      last: "done",
    },
    {
      fname1: "Action",
      lname1: "was ",
      last: "done",
    },
  ]);

  const manage = [
    {
      fname1: "Process ",
      lname1: "is ",
      last: "not Complete",
    },
    {
      fname1: "Works ",
      lname1: "are ",
      last: " not done",
    },
    {
      fname1: "Action",
      lname1: "was ",
      last: "done",
    },
  ];
  const handleChange = () => {
    setNewName(manage);
  };

  return (
    <>
      <StateChild arrObj={data} handleFunc={handleChange}></StateChild>
    </>
  );
}
export default StateChange;
