import React, { useRef } from "react";

//unColtrolled component as controlled by DOM
//to know the current state from DOM => useRef lifecycle hook

function UseRefHook() {
  const inputElement = useRef(null);
  const onButtonClick = () => {
    // 'current' points to the muted text input element
    console.log(inputElement.current);
    inputElement.current.focus();
    //collecting value from input field using useRef
    console.log("input field value: ", inputElement.current.value);
  };
  return (
    <>
      <input ref={inputElement} type="text" />
      <button onClick={onButtonClick}>Focus the input</button>
    </>
  );
}

export default UseRefHook;
