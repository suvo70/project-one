import React from "react";

function UseMemoHook() {
  return <div></div>;
}

export default UseMemoHook;
