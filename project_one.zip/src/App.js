//import logo from "./logo.svg";
import React, { useState } from "react";
import "./App.css";
// import UseMemoHook from "./LifeCycleHook/UseMemoHook";
// import UseReduceHook from "./LifeCycleHook/UseReduceHook/UseReduceHook";
import { AuseContext } from "./UseComponent/A/AuseContext";
// import UseRefHook from "./LifeCycleHook/UseRefHook";
// import CompontDidUpdate from "./ComponentUpdate/CompontDidUpdate";
// import ComponentWillUpdate from "./ComponentWillUpdate/ComponentWillUpdate";
// import Fparent from "./ShouldFunctionComponent/ParentFnc";
// import ComponentDidMount from "./LifeCycleMethod/ComponentDidMount";
// import GetDerived from "./LifeCycleMethod/GetDerived";
// import ChildClass from "./ClassComponent/ChildClass";
// import ParentClass from "./ClassComponent/ParentClass";
// import StateClass from "./ClassComponent/StateClass";
// import LifeCycleMethod from "./LifeCycleMethod/LifeCycleMethod";
// import ParentComponent from "./ShouldComponent/ParentComponent";
// import ParentFnc from "./ShouldFunctionComponent/ParentFnc";
// import UpdateValue from "./LifeCycleMethod/UpdateValue";
// import StateChange from "./component/StateChange";
// import Test, { Next, Plus } from "./component/test/test";
// import Test1 from "./component/test/test1";
// import Parent from "./crossComponent/parent/parent";

export const userDetailContext = React.createContext(null);
function App() {
  const [userDetails, setuserDetails] = useState({
    name: "ABCDE",
    age: 30,
  });
  return (
    <div className="App">
      {/* <Test />
      <Next />
      <Plus />
      <Test1 /> */}
      {/* <Parent />
      <StateChange /> */}
      {/* <ParentClass />
      <StateClass /> */}
      {/* <LifeCycleMethod /> */}
      {/* <GetDerived favColor="blue" />
      <ComponentDidMount /> */}
      {/* <UpdateValue /> */}
      {/* <ParentComponent />
      <ParentFnc /> */}
      {/* <CompontDidUpdate />
      <ComponentWillUpdate /> */}
      {/* <Fparent /> */}
      {/* <UseRefHook />
      <UseMemoHook /> */}
      {/* <UseReduceHook /> */}
      <userDetailContext.Provider value={userDetails}>
        <AuseContext />
      </userDetailContext.Provider>
    </div>
  );
}

export default App;
