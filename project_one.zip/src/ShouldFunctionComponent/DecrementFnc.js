// import React from "react";

// const FDecre = (props) => {
//   //console.log("Function Decrement", props);
//   return (
//     <div>
//       <h1>{props.data}</h1>
//       <button onClick={props.func}>Click to decrease</button>
//     </div>
//   );
// };

// export default React.memo(
//   FDecre,
//   (prevProps, nextProps) => prevProps.data === nextProps.data
// );

import React from "react";

export function DecrementFnc(props) {
  console.log("decrement");
  console.log("props:", props);
  return (
    <div>
      <React.Component>
        <h1>{props.data.prevalue}</h1>
        <button onClick={props.func}>Click</button>
      </React.Component>
    </div>
  );
}
