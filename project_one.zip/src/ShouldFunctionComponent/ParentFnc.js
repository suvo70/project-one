// import React, { useState } from "react";
// import DecrementFnc from "./DecrementFnc";
// import IncrementFnc from "./IncrementFnc";

// function ParentFnc() {
//   const [increment, setIncrement] = useState(0);
//   const [decrement, setDecrement] = useState(0);

//   let handleIncrement = () => {
//     setIncrement(increment + 1);
//   };
//   let handleDecrement = () => {
//     setDecrement(decrement - 1);
//   };
//   return (
//     <div>
//       <IncrementFnc data={increment} func={handleIncrement}></IncrementFnc>
//       <DecrementFnc data={decrement} func={handleDecrement}></DecrementFnc>
//     </div>
//   );
// }

// export default ParentFnc;

import React, { useState } from "react";
import { DecrementFnc } from "./DecrementFnc";
// import { Fdecrement } from "./fdecrement";
// import { Fincrement } from "./fincrement";
import { IncrementFnc } from "./IncrementFnc";

export default function Fparent() {
  const [data, newState] = useState({
    //in brackets 1st item is current data next one is function usestae returns
    currentvalue: 0,
    prevalue: 0,
  });
  const increment = () => {
    newState({
      currentvalue: data.currentvalue - 1,
      prevalue: data.prevalue,
    });
  };
  const decrement = () => {
    newState({
      currentvalue: data.currentvalue,
      prevalue: data.prevalue - 1,
    });
  };
  return (
    <>
      <IncrementFnc data={data} func={increment} />
      <DecrementFnc data={data} func={decrement} />
    </>
  );
}
