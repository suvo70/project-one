// import React from "react";

// export default React.memo(
//   function FIncre(props) {
//     //console.log("Function Increment");
//     return (
//       <div>
//         <h1>{props.data}</h1>
//         <button onClick={props.func}>Click To increase</button>
//       </div>
//     );
//   },
//   (prevProps, nextProps) => prevProps.data === nextProps.data
// );

import React from "react";

export function IncrementFnc(props) {
  console.log("Increment");
  console.log("Props", props);
  return (
    <>
      <React.Component>
        <h1>{props.data.currentvalue}</h1>
        <button onClick={props.func}>Click</button>
      </React.Component>
    </>
  );
}
