import React from "react";
import { CuseContext } from "../C/CuseContext";

export const BuseContext = () => {
  return (
    <div>
      <p>C component</p>
      <CuseContext />
    </div>
  );
};
