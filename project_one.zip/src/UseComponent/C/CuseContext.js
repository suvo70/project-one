import React, { useContext } from "react";
import { userDetailContext } from "../../App";

export const CuseContext = () => {
  const contextData = useContext(userDetailContext);
  console.log("context value: ", contextData);
  return (
    <div>
      <h3>This is a Suv Child Component</h3>
      <h4>User Name: {contextData.name}</h4>
      <h4>User Age: {contextData.age}</h4>
    </div>
  );
};
