import React from "react";
import { BuseContext } from "../B/BuseContext";

export const AuseContext = () => {
  return (
    <div>
      <p>B component</p>
      <BuseContext />
    </div>
  );
};
