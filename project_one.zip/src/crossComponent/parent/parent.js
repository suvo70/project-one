import React, { useState } from "react";
import Child from "../child/child";

function Parent() {
  let value = "Parent value";
  let a = "jack";
  let b = {
    fname: "Data",
    lname: "Object",
  };

  const [net, c] = useState([
    {
      fname: "ABC",
      lname: "CD",
    },
    {
      fname: "CDE",
      lname: "EF",
    },
    {
      fname: "GHI",
      lname: "IJ",
    },
  ]);
  const d = [
    {
      fname: "GHI",
      lname: "IJ",
    },
    {
      fname: "CDE",
      lname: "EF",
    },
    {
      fname: "ABC",
      lname: "CD",
    },
  ];

  const handleChange1 = () => {
    c(d);
  };
  return (
    <div>
      <p>This is parent-chiild process</p>
      <Child
        data="Javascript"
        data1={a}
        data2={b}
        data3={net}
        handleFnc1={handleChange1}
      >
        {value}
      </Child>
    </div>
  );
}

export default Parent;
