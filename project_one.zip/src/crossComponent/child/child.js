import React from "react";

export const Child = (props) => {
  console.log("Child value :", props);
  return (
    <>
      <p> Child </p>
      <h1>{props.children}</h1>
      <h1>{props.data}</h1>
      <h1>
        {props.data2.fname}
        {props.data2.lname}
      </h1>
      {props.data3.map((net, index) => (
        <React.Fragment key={index}>
          <h1>
            {net.fname} {net.lname}
          </h1>
        </React.Fragment>
      ))}
      <button onClick={props.handleFnc1}>Click me</button>
    </>
  );
};

export default Child;
