import React, { Component } from "react";
import ChildClass from "./ChildClass";

export default class ParentClass extends Component {
  name = "Ford";
  abc = {
    id: 123,
    ename: "Jhonson",
  };
  render() {
    return (
      <div>
        <ChildClass data={this.abc}>{this.name}</ChildClass>
      </div>
    );
  }
}
