import React, { Component } from "react";

export default class ChildClass extends Component {
  render() {
    console.log(this.props);
    return (
      <div>
        <h1>
          {this.props.children}
          {this.props.data.id}
          {this.props.data.ename}
        </h1>
      </div>
    );
  }
}
