import React, { Component } from "react";

export default class StateClass extends Component {
  constructor() {
    super();
    this.state = {
      a: 123,
      click: 0,
    };
    // this.haldleChange2 = this.haldleChange2.bind(this);
    // this.haldleChange3 = this.haldleChange3.bind(this);
  }

  haldleChange2 = () => {
    this.setState({ a: 456 });
  };
  haldleChange3 = () => {
    this.setState({ click: this.state.click + 1 });
  };
  render() {
    return (
      <>
        <h1>{this.state.a}</h1>
        <button onClick={this.haldleChange2}>change</button>
        {/* <button
          onClick={() => {
            this.setState({ a: 456 });
          }}
        >
          Change me
        </button> */}
        <h2>{this.state.click}</h2>
        <button onClick={this.haldleChange3}>count</button>
      </>
    );
  }
}
