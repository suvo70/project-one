import React, { Component } from "react";

export default class ComponentDidMount extends Component {
  state = {
    data: "abc",
  };
  changeData() {
    setTimeout(() => {
      alert("Data Updated");
      this.setState({
        data: "ABCD",
      });
    }, 6000);
  }
  componentDidMount() {
    this.changeData();
  }
  render() {
    return (
      <div>
        <h1>{this.state.data}</h1>
      </div>
    );
  }
}
