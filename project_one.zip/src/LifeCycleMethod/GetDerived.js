import React, { Component } from "react";

export default class GetDerived extends Component {
  state = {
    favColorState: "red",
  };
  static getDerivedStateFromProps(props, state) {
    if (state.favColorState !== props.favColor) {
      console.log("Props value: ", props);
      console.log("state value: ", state);
      return { favColorState: props.favColor };
    }
  }
  render() {
    return (
      <div>
        <h1>My fev color is {this.state.favColorState}</h1>
      </div>
    );
  }
}
