import React, { Component } from "react";

export default class UpdateValue extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isToggleOn: true,
    };
  }
  handleClick = () => {
    this.setState((state) => ({
      isToggleOn: !state.isToggleOn,
    }));
  };

  render() {
    return (
      <div>
        <h1>{this.state.isToggleOn ? "Suvayan Karmakar" : " "}</h1>
        <button onClick={this.handleClick}>Change</button>
      </div>
    );
  }
}
