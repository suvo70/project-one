import React, { Component } from "react";

export default class LifeCycleMethod extends Component {
  constructor() {
    super();
    this.state = {
      process: 123,
    };
    console.log("constructor phase");
  }
  static getDerivedStateFromProps(props, state) {
    console.log("get derived phase");
    return null;
  }
  componentDidMount() {
    console.log("component phase");
  }

  render() {
    console.log("render phase");
    return (
      <div>
        <h1>Life cycle method of class component.</h1>
      </div>
    );
  }
}
